<footer>
    <div class="pull-right">
      © Copyright 2022, Kanxiko.com
    </div>
    <div class="clearfix"></div>
</footer>