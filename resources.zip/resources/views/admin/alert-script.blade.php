<script>
    $("document").ready(function(){
        setTimeout(function(){
           $("div.alert-success").remove();
        }, 3000 ); // 5 secs      
    });
    setTimeout(function(){
           $("div.alert-danger").remove();
        }, 3000 ); // 5 secs  
</script>